package com.hardBody.hardBody;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HardBodyApplicationTests {

	@Test
	void contextLoads() {
	}

}
