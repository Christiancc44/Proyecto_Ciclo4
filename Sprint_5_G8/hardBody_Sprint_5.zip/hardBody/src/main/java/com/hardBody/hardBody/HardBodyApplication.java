package com.hardBody.hardBody;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HardBodyApplication {

	public static void main(String[] args) {
		SpringApplication.run(HardBodyApplication.class, args);
	}

}
