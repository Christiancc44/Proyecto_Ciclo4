import React from "react";
import {
  Switch,
  Route,
  BrowserRouter,
} from "react-router-dom";
import Entrenador from "../pages/Entrenador";
import Cliente from "../pages/Cliente";
import Home from "../pages/Homepage";
import NotFound from "../pages/NotFound";
function App() {
  return (
    <BrowserRouter>
      <div className=" container mt-5">
        <Switch>
          <Route exact path="/home" component={Home} />
          <Route exact path="/entrenador" component={Entrenador}/>
          <Route exact path="/cliente" component={Cliente}/>
          <Route path="*" component={NotFound}/>
        </Switch>
        
      </div>
      </BrowserRouter>
  );
}

export default App;
