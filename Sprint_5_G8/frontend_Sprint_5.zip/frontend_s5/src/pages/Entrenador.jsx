import React from 'react'
import { NavBar } from '../components/NavBar'
import TablaEntrenador from '../components/TablaEntrenador'

const Entrenador = () => {
    return (
        <div>
            <img src="banner2.png" className='img-fluid' alt="banner"></img>
            <NavBar/>
            <TablaEntrenador/>

        </div>
    )
}

export default Entrenador
