import React from 'react'
import {NavBar} from '../components/NavBar'
import TableCliente from '../components/TableCliente'


const Clientes = () => {
    return (
        <div>
            <img src="banner2.png" class="img-fluid" alt="banner"></img>
            <NavBar/>
           <TableCliente/>
        </div>
    )
}

export default Clientes