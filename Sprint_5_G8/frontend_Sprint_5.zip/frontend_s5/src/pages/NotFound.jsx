import React from 'react'

const NotFound = () => {
    return (
        <div>
            <h2>Not Found</h2>
            <img src="gifbascula.gif" className="rounded mx-auto d-block" alt="Bascula"></img>
        </div>
    )
}

export default NotFound
