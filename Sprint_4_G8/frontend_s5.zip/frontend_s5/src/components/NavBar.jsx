import React from 'react'
import { Link } from 'react-router-dom'

export const NavBar = () => {
    return (
        
        <div className="d-grid gap-2 d-md-flex"> 
        <Link to="/home" className="btn btn-dark">
        Home
        </Link>
        <Link to="/cliente" className="btn btn-dark">
        Cliente
        </Link>
        <Link to="/entrenador" className="btn btn-dark">
        Entrenador
        </Link>
        </div>
    )
}
