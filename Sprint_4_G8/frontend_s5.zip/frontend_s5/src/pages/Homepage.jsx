import React from 'react'
import { scryRenderedComponentsWithType } from 'react-dom/cjs/react-dom-test-utils.production.min'
import { NavBar } from '../components/NavBar'

const Home = () => {
    return (
        <div>
            <NavBar/>
            <h1 className="text-center">Bienvenidos</h1>
            <img src="Hardbody.png" className="rounded mx-auto d-block" alt="Gym"></img>
            
        </div>
    )  
}

export default Home